﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Your_weight_on_Saturn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            //variables stored here...
             float earthWeight; // holds earth input from user input from textbox.

           
             float solve; // holds the formula to calculate and find the vallue.

            earthWeight = float.Parse(earthBox.Text);


            solve = (float)((earthWeight / 9.81) * 10.44);

            MessageBox.Show("Your weight on saturn is" + solve);

            saturnBox.Text = solve.ToString();




            this.convertButton.Click += new EventHandler(button1_Click);
        }

        private void saturnBox_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
